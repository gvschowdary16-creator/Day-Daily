// DAYDIAL: Calendar, Events, Photo Gallery and Theme

const $ = id => document.getElementById(id);

let currentDate = new Date();
let selectedDate = new Date();

let events = JSON.parse(
  localStorage.getItem("daydialEvents") || "[]"
);

let editingId = null;

// DATE FUNCTIONS

function keyDate(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function prettyDate(d) {
  return d.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });
}

function save() {
  localStorage.setItem(
    "daydialEvents",
    JSON.stringify(events)
  );

  $("eventCount").textContent = events.length;
}

$("todayDate").textContent = new Date().toLocaleDateString(
  "en-IN",
  { day: "numeric", month: "short" }
);

// CALENDAR DISPLAY

function renderCalendar() {

  const y = currentDate.getFullYear();
  const m = currentDate.getMonth();

  const first = new Date(y, m, 1).getDay();
  const last = new Date(y, m + 1, 0).getDate();

  $("monthYear").textContent =
    currentDate.toLocaleDateString("en-IN", {
      month: "long",
      year: "numeric"
    });

  $("calendarDays").innerHTML = "";

  // Empty spaces before first date

  for (let i = 0; i < first; i++) {
    $("calendarDays").appendChild(
      document.createElement("div")
    );
  }

  // Create calendar dates

  for (let day = 1; day <= last; day++) {

    const d = new Date(y, m, day);
    const k = keyDate(d);

    const b = document.createElement("button");

    b.type = "button";
    b.className = "calendar-day";
    b.textContent = day;

    // Today's date

    if (k === keyDate(new Date())) {
      b.classList.add("today");
    }

    // Selected date

    if (k === keyDate(selectedDate)) {
      b.classList.add("selected");
    }

    // Show dot if event exists

    if (events.some(e => e.date === k)) {

      const dot = document.createElement("span");

      dot.className = "day-dot";

      b.appendChild(dot);
    }

    // Select date

    b.onclick = () => {

      selectedDate = d;

      renderCalendar();
      renderAgenda();

    };

    $("calendarDays").appendChild(b);
  }
}

// DAILY AGENDA

function renderAgenda() {

  $("selectedDateTitle").textContent =
    prettyDate(selectedDate);

  const list = events
    .filter(e => e.date === keyDate(selectedDate))
    .sort((a, b) =>
      (a.time || "").localeCompare(b.time || "")
    );

  $("agendaList").innerHTML = "";

  // No events message

  if (!list.length) {

    $("agendaList").innerHTML = `
      <div class="empty-agenda">
        ✦<br>
        No events planned for this day.<br>
        Add a special moment to your calendar.
      </div>
    `;

    return;
  }

  // Display events

  list.forEach(e => {

    const card = document.createElement("div");

    card.className = "agenda-item";

    const h = document.createElement("h4");
    h.textContent = e.name;

    const p = document.createElement("p");
    p.textContent =
      `${e.time || "Time not set"} · ${e.category}`;

    card.append(h, p);

    // Location

    if (e.location) {

      const loc = document.createElement("p");

      loc.textContent = "⌖ " + e.location;

      card.appendChild(loc);
    }

    // Description

    if (e.description) {

      const desc = document.createElement("p");

      desc.textContent = e.description;

      card.appendChild(desc);
    }

    // Edit and Delete buttons

    const actions = document.createElement("div");

    actions.className = "agenda-actions";

    const edit = document.createElement("button");

    edit.textContent = "Edit";

    edit.onclick = () => editEvent(e.id);

    const del = document.createElement("button");

    del.textContent = "Delete";

    del.onclick = () => deleteEvent(e.id);

    actions.append(edit, del);

    card.appendChild(actions);

    $("agendaList").appendChild(card);

  });
}

// MONTH NAVIGATION

$("prevMonth").onclick = () => {

  currentDate.setMonth(
    currentDate.getMonth() - 1
  );

  renderCalendar();
};

$("nextMonth").onclick = () => {

  currentDate.setMonth(
    currentDate.getMonth() + 1
  );

  renderCalendar();
};

$("todayBtn").onclick = () => {

  currentDate = new Date();
  selectedDate = new Date();

  renderCalendar();
  renderAgenda();

};

// EVENT POPUP

function openModal() {

  $("eventModal").classList.add("show");

}

function closeModal() {

  $("eventModal").classList.remove("show");

  $("eventForm").reset();

  editingId = null;

  $("modalTitle").textContent = "Add Your Event";

}

// ADD EVENT BUTTON

$("openModalBtn").onclick = () => {

  $("eventDate").value = keyDate(selectedDate);

  editingId = null;

  $("modalTitle").textContent = "Add Your Event";

  openModal();

};

// CLOSE POPUP

$("closeModalBtn").onclick = closeModal;

$("eventModal").onclick = e => {

  if (e.target === $("eventModal")) {
    closeModal();
  }

};

// SAVE EVENT

$("eventForm").onsubmit = e => {

  e.preventDefault();

  const date = $("eventDate").value;

  const name = $("eventName").value.trim();

  if (!name || !date) {

    alert("Please enter the event name and date.");

    return;
  }

  const item = {

    id: editingId || Date.now(),

    name: name,

    date: date,

    time: $("eventTime").value,

    category: $("eventCategory").value,

    location: $("eventLocation").value.trim(),

    description: $("eventDescription").value.trim()

  };

  // Update existing event

  if (editingId) {

    events = events.map(x =>
      x.id === editingId ? item : x
    );

  } else {

    // Add new event

    events.push(item);

  }

  save();

  selectedDate = new Date(date + "T00:00:00");

  currentDate = new Date(date + "T00:00:00");

  renderCalendar();

  renderAgenda();

  closeModal();

};

// EDIT EVENT

function editEvent(id) {

  const e = events.find(x => x.id === id);

  if (!e) return;

  editingId = id;

  $("eventName").value = e.name;

  $("eventDate").value = e.date;

  $("eventTime").value = e.time || "";

  $("eventCategory").value = e.category;

  $("eventLocation").value = e.location || "";

  $("eventDescription").value = e.description || "";

  $("modalTitle").textContent = "Edit Your Event";

  openModal();

}

// DELETE EVENT

function deleteEvent(id) {

  if (!confirm("Do you want to delete this event?")) {
    return;
  }

  events = events.filter(e => e.id !== id);

  save();

  renderCalendar();

  renderAgenda();

}

// ROYAL EVENTS GALLERY

// These are sample stock photographs.
// They are illustrative images, not verified TDP or Jana Sena photographs.

const photos = [

  [
    "TDP Party Meeting",
    "political",
    "A party meeting and discussion.",
    "photo-1475721027785-f74eccf877e2"
  ],

  [
    "Jana Sena Meeting",
    "political",
    "A political organisation meeting.",
    "photo-1540575467063-178a50c2df87"
  ],

  [
    "Political Convention",
    "political",
    "A formal convention gathering.",
    "photo-1511578314322-379afb476865"
  ],

  [
    "TDP & Jana Sena Joint Meeting",
    "political",
    "A joint party meeting.",
    "photo-1505373877841-8d25f7d46678"
  ],

  [
    "Party Conference",
    "political",
    "A conference and group discussion.",
    "photo-1515187029135-18ee286d815b"
  ],

  [
    "Party Workers Meeting",
    "political",
    "A meeting with party members.",
    "photo-1517048676732-d65bc937f952"
  ],

  [
    "Royal Wedding",
    "celebration",
    "A beautiful wedding celebration.",
    "photo-1519741497674-611481863552"
  ],

  [
    "Birthday Celebration",
    "celebration",
    "A special birthday party.",
    "photo-1530103862676-de8c9debad1d"
  ],

  [
    "Family Moments",
    "family",
    "Beautiful memories with family.",
    "photo-1511895426328-dc8714191300"
  ],

  [
    "Engagement Ceremony",
    "celebration",
    "A memorable engagement occasion.",
    "photo-1523438885200-e635ba2c371e"
  ],

  [
    "Anniversary",
    "celebration",
    "Celebrating a special milestone.",
    "photo-1464366400600-7168b8af9bc3"
  ],

  [
    "Housewarming",
    "celebration",
    "A new home and a new beginning.",
    "photo-1600210492486-724fe5c67fb0"
  ],

  [
    "Diwali Festival",
    "festival",
    "A beautiful festival of lights.",
    "photo-1605640840605-14ac1855827b"
  ],

  [
    "Sankranti Festival",
    "festival",
    "A colourful harvest celebration.",
    "photo-1513415564515-763d91423bdd"
  ],

  [
    "College Event",
    "college",
    "A memorable college gathering.",
    "photo-1523580494863-6f3031224c94"
  ],

  [
    "Hackathon",
    "college",
    "Innovation, teamwork and technology.",
    "photo-1504384308090-c894fdcc538d"
  ],

  [
    "Family Picnic",
    "family",
    "A wonderful day outdoors.",
    "photo-1478131143081-80f7f84ca84d"
  ],

  [
    "Wedding Reception",
    "celebration",
    "An elegant reception celebration.",
    "photo-1465495976277-4387d4b0e4a6"
  ],

  [
    "College Farewell",
    "other",
    "A memorable farewell gathering.",
    "photo-1529156069898-49953e39b3ac"
  ],

  [
    "Cultural Events",
    "other",
    "Art, culture and celebrations.",
    "photo-1503095396549-807759245b35"
  ]

].map(([title, category, description, id]) => ({

  title,

  category,

  description,

  image: `https://images.unsplash.com/${id}?auto=format&fit=crop&w=700&q=80`

}));

// GALLERY FILTER

let activeCategory = "all";

function renderGallery() {

  const q = $("gallerySearch").value
    .toLowerCase()
    .trim();

  const filtered = photos.filter(p =>

    (activeCategory === "all" ||
      p.category === activeCategory) &&

    (
      p.title.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q)
    )

  );

  $("eventGallery").innerHTML = "";

  filtered.forEach(p => {

    const n = photos.indexOf(p) + 1;

    const card = document.createElement("article");

    card.className = "gallery-card";

    const area = document.createElement("div");

    area.className = "gallery-image";

    const img = document.createElement("img");

    img.src = p.image;

    img.alt = p.title;

    img.loading = "lazy";

    // Fallback if photo does not load

    img.onerror = () => {

      img.style.display = "none";

      area.textContent = "✦ " + p.title;

      area.style.cssText +=
        ";display:grid;place-items:center;" +
        "color:#fff4dc;font-family:Georgia;" +
        "padding:15px;text-align:center;" +
        "background:linear-gradient(135deg,#493021,#c6a15b)";

    };

    const num = document.createElement("span");

    num.className = "gallery-number";

    num.textContent = String(n).padStart(2, "0");

    area.append(img, num);

    const info = document.createElement("div");

    info.className = "gallery-info";

    const cat = document.createElement("span");

    cat.className = "gallery-category";

    cat.textContent = p.category;

    const title = document.createElement("h3");

    title.textContent = p.title;

    const desc = document.createElement("p");

    desc.textContent = p.description;

    info.append(cat, title, desc);

    card.append(area, info);

    $("eventGallery").appendChild(card);

  });

  $("noGalleryResults").hidden = filtered.length !== 0;

}

// SEARCH EVENTS

$("gallerySearch").addEventListener(
  "input",
  renderGallery
);

// CATEGORY FILTER BUTTONS

document.querySelectorAll(".filter-btn").forEach(btn => {

  btn.onclick = () => {

    document.querySelectorAll(".filter-btn")
      .forEach(b => b.classList.remove("active"));

    btn.classList.add("active");

    activeCategory = btn.dataset.category;

    renderGallery();

  };

});

// DARK AND LIGHT THEME

$("themeBtn").onclick = () => {

  document.body.classList.toggle("dark-mode");

  const dark =
    document.body.classList.contains("dark-mode");

  $("themeBtn").textContent = dark ? "☀" : "☾";

  localStorage.setItem(
    "daydialTheme",
    dark ? "dark" : "light"
  );

};

// REMEMBER THEME

if (localStorage.getItem("daydialTheme") === "dark") {

  document.body.classList.add("dark-mode");

  $("themeBtn").textContent = "☀";

}

// START WEBSITE

save();

renderCalendar();

renderAgenda();

renderGallery();